-- Audit trigger: logs balance and status changes on accounts_demo

CREATE TABLE accounts_audit_demo (
  audit_id    NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  account_id  NUMBER,
  old_balance NUMBER(14,2),
  new_balance NUMBER(14,2),
  old_status  VARCHAR2(10),
  new_status  VARCHAR2(10),
  changed_by  VARCHAR2(50),
  changed_on  DATE
);

CREATE OR REPLACE TRIGGER trg_accounts_audit_demo
AFTER UPDATE OF balance, status ON accounts_demo
FOR EACH ROW
BEGIN
  INSERT INTO accounts_audit_demo
    (account_id, old_balance, new_balance, old_status, new_status, changed_by, changed_on)
  VALUES
    (:OLD.account_id, :OLD.balance, :NEW.balance, :OLD.status, :NEW.status, USER, SYSDATE);
END trg_accounts_audit_demo;
/
