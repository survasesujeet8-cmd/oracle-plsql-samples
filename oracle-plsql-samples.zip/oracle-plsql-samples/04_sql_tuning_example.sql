-- SQL tuning example: find transactions for one account in a date range

-- 1. Slow version: function on the column blocks index use, no supporting index
EXPLAIN PLAN FOR
SELECT * FROM txn_demo
 WHERE account_id = 1
   AND TRUNC(txn_date) = TRUNC(SYSDATE);

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);   -- expect TABLE ACCESS FULL on large tables

-- 2. Add a composite index
CREATE INDEX idx_txn_account_date ON txn_demo (account_id, txn_date);

-- 3. Rewrite to a range condition so the index can be used
EXPLAIN PLAN FOR
SELECT txn_id, txn_type, amount, txn_date
  FROM txn_demo
 WHERE account_id = 1
   AND txn_date >= TRUNC(SYSDATE)
   AND txn_date <  TRUNC(SYSDATE) + 1;

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);  -- expect INDEX RANGE SCAN on idx_txn_account_date

-- 4. Refresh optimizer statistics
BEGIN
  DBMS_STATS.GATHER_TABLE_STATS(USER, 'TXN_DEMO');
END;
/

/* Summary:
   - Avoid functions on indexed columns in WHERE clauses
   - Put the equality column first in a composite index
   - Select only the columns you need
   - Keep statistics up to date */
