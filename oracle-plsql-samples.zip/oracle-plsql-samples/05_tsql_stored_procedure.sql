-- SQL Server (T-SQL) sample: monthly transaction summary per account

CREATE TABLE dbo.Accounts_Demo (
  AccountId    INT PRIMARY KEY,
  CustomerName VARCHAR(100) NOT NULL,
  Balance      DECIMAL(14,2) NOT NULL DEFAULT 0
);

CREATE TABLE dbo.Txn_Demo (
  TxnId     INT IDENTITY(1,1) PRIMARY KEY,
  AccountId INT NOT NULL REFERENCES dbo.Accounts_Demo(AccountId),
  TxnType   VARCHAR(10) NOT NULL,
  Amount    DECIMAL(14,2) NOT NULL,
  TxnDate   DATETIME NOT NULL DEFAULT GETDATE()
);
GO

CREATE OR ALTER PROCEDURE dbo.usp_MonthlySummary
  @Year  INT,
  @Month INT
AS
BEGIN
  SET NOCOUNT ON;

  BEGIN TRY
    IF @Month NOT BETWEEN 1 AND 12
      THROW 50001, 'Invalid month', 1;

    ;WITH MonthTxn AS (
      SELECT AccountId,
             SUM(CASE WHEN TxnType = 'DEPOSIT'  THEN Amount ELSE 0 END) AS TotalDeposits,
             SUM(CASE WHEN TxnType = 'WITHDRAW' THEN Amount ELSE 0 END) AS TotalWithdrawals,
             COUNT(*) AS TxnCount
        FROM dbo.Txn_Demo
       WHERE YEAR(TxnDate) = @Year AND MONTH(TxnDate) = @Month
       GROUP BY AccountId
    )
    SELECT a.AccountId, a.CustomerName,
           ISNULL(m.TotalDeposits, 0)    AS TotalDeposits,
           ISNULL(m.TotalWithdrawals, 0) AS TotalWithdrawals,
           ISNULL(m.TxnCount, 0)         AS TxnCount
      FROM dbo.Accounts_Demo a
      LEFT JOIN MonthTxn m ON m.AccountId = a.AccountId
     ORDER BY a.AccountId;
  END TRY
  BEGIN CATCH
    SELECT ERROR_NUMBER() AS ErrNo, ERROR_MESSAGE() AS ErrMsg;
    THROW;
  END CATCH
END;
GO

EXEC dbo.usp_MonthlySummary @Year = 2026, @Month = 1;
