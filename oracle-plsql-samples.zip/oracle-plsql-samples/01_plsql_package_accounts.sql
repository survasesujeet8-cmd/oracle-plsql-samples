-- Oracle PL/SQL sample: accounts and transactions (dummy data)

CREATE TABLE accounts_demo (
  account_id   NUMBER PRIMARY KEY,
  customer_name VARCHAR2(100) NOT NULL,
  balance      NUMBER(14,2) DEFAULT 0 NOT NULL,
  status       VARCHAR2(10) DEFAULT 'ACTIVE' NOT NULL,
  created_on   DATE DEFAULT SYSDATE
);

CREATE TABLE txn_demo (
  txn_id      NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  account_id  NUMBER NOT NULL REFERENCES accounts_demo(account_id),
  txn_type    VARCHAR2(10) NOT NULL CHECK (txn_type IN ('DEPOSIT','WITHDRAW')),
  amount      NUMBER(14,2) NOT NULL CHECK (amount > 0),
  txn_date    DATE DEFAULT SYSDATE
);

CREATE OR REPLACE PACKAGE pkg_accounts_demo AS
  insufficient_funds EXCEPTION;
  PRAGMA EXCEPTION_INIT(insufficient_funds, -20001);

  PROCEDURE post_transaction(p_account_id IN NUMBER, p_type IN VARCHAR2, p_amount IN NUMBER);
  FUNCTION  get_balance(p_account_id IN NUMBER) RETURN NUMBER;
  PROCEDURE flag_dormant_accounts(p_days IN NUMBER DEFAULT 365);
END pkg_accounts_demo;
/

CREATE OR REPLACE PACKAGE BODY pkg_accounts_demo AS

  FUNCTION get_balance(p_account_id IN NUMBER) RETURN NUMBER IS
    v_balance accounts_demo.balance%TYPE;
  BEGIN
    SELECT balance INTO v_balance FROM accounts_demo WHERE account_id = p_account_id;
    RETURN v_balance;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20002, 'Account not found: ' || p_account_id);
  END get_balance;

  PROCEDURE post_transaction(p_account_id IN NUMBER, p_type IN VARCHAR2, p_amount IN NUMBER) IS
    v_balance accounts_demo.balance%TYPE;
  BEGIN
    SELECT balance INTO v_balance
      FROM accounts_demo
     WHERE account_id = p_account_id
       FOR UPDATE;

    IF p_type = 'WITHDRAW' AND v_balance < p_amount THEN
      RAISE_APPLICATION_ERROR(-20001, 'Insufficient funds');
    END IF;

    UPDATE accounts_demo
       SET balance = CASE WHEN p_type = 'DEPOSIT' THEN balance + p_amount
                          ELSE balance - p_amount END
     WHERE account_id = p_account_id;

    INSERT INTO txn_demo (account_id, txn_type, amount) VALUES (p_account_id, p_type, p_amount);
    COMMIT;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      ROLLBACK;
      RAISE_APPLICATION_ERROR(-20002, 'Account not found: ' || p_account_id);
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE;
  END post_transaction;

  -- Bulk processing: mark accounts with no transactions for p_days as DORMANT
  PROCEDURE flag_dormant_accounts(p_days IN NUMBER DEFAULT 365) IS
    TYPE t_ids IS TABLE OF accounts_demo.account_id%TYPE;
    v_ids t_ids;
  BEGIN
    SELECT a.account_id BULK COLLECT INTO v_ids
      FROM accounts_demo a
     WHERE a.status = 'ACTIVE'
       AND NOT EXISTS (SELECT 1 FROM txn_demo t
                        WHERE t.account_id = a.account_id
                          AND t.txn_date > SYSDATE - p_days);

    FORALL i IN 1 .. v_ids.COUNT
      UPDATE accounts_demo SET status = 'DORMANT' WHERE account_id = v_ids(i);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE(v_ids.COUNT || ' accounts flagged as dormant');
  END flag_dormant_accounts;

END pkg_accounts_demo;
/

-- Test with dummy data
INSERT INTO accounts_demo (account_id, customer_name, balance) VALUES (1, 'Demo Customer', 1000);
COMMIT;

BEGIN
  pkg_accounts_demo.post_transaction(1, 'DEPOSIT', 500);
  DBMS_OUTPUT.PUT_LINE('Balance: ' || pkg_accounts_demo.get_balance(1));
END;
/
