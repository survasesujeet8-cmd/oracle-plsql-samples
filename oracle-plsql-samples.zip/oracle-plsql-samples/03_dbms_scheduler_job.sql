-- Nightly maintenance job using DBMS_SCHEDULER: flags dormant accounts at 01:00 every day

BEGIN
  DBMS_SCHEDULER.CREATE_JOB (
    job_name        => 'JOB_FLAG_DORMANT_ACCOUNTS',
    job_type        => 'PLSQL_BLOCK',
    job_action      => 'BEGIN pkg_accounts_demo.flag_dormant_accounts(365); END;',
    start_date      => SYSTIMESTAMP,
    repeat_interval => 'FREQ=DAILY; BYHOUR=1; BYMINUTE=0; BYSECOND=0',
    enabled         => TRUE,
    comments        => 'Nightly dormant account check (demo)'
  );
END;
/

-- Check job status and run history
SELECT job_name, enabled, state, last_start_date, next_run_date
  FROM user_scheduler_jobs
 WHERE job_name = 'JOB_FLAG_DORMANT_ACCOUNTS';

SELECT job_name, status, actual_start_date, run_duration, additional_info
  FROM user_scheduler_job_run_details
 WHERE job_name = 'JOB_FLAG_DORMANT_ACCOUNTS'
 ORDER BY actual_start_date DESC;
