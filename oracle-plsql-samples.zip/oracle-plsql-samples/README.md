# Oracle PL/SQL and SQL Server Samples

Author: Sujeet Laxman Survase | Oracle PL/SQL Developer | Pune, India
Contact: survasesujeet8@gmail.com

Sample database scripts written with dummy data only. No client or confidential data is used.

| File | What it shows |
|---|---|
| 01_plsql_package_accounts.sql | Tables, PL/SQL package, procedures, functions, cursor, bulk processing, exception handling |
| 02_audit_trigger.sql | Row-level audit trigger for change tracking |
| 03_dbms_scheduler_job.sql | Nightly maintenance job using DBMS_SCHEDULER |
| 04_sql_tuning_example.sql | Slow query, index fix, execution plan comparison |
| 05_tsql_stored_procedure.sql | SQL Server stored procedure with CTE, TRY...CATCH, transaction |

## Skills
Oracle PL/SQL, SQL tuning, indexing, triggers, DBMS_SCHEDULER, T-SQL, stored procedures, error handling.
